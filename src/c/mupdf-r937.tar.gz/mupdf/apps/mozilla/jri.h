/* dummy jri */
#define jref void*
#define JRIEnv void
#define JRIGlobalRef void*
#define JRI_NewGlobalRef(e,c) 0

